package spring;

public class WrongIdPasswordException extends RuntimeException {

}
