package sp5.sp5chapb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp5ChapbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp5ChapbApplication.class, args);
	}
}
